
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

</head>
<body>

<footer class="footer_home">
  	 <div class="container">
  	 	<div class="row">

           <div class="footer-col">
  	 			<?php
                    require "shop-name.php";
                ?>
  	 		</div>
  	 		<div class="footer-col">
  	 			<h4>company</h4>
  	 			<ul>
  	 				<li><a href="#">our products</a></li>
  	 				<li><a href="#">contact us</a></li>
  	 			</ul>
  	 		</div>

  	 		<div class="footer-col">
  	 			<h4>online shop</h4>
  	 			<ul>
  	 				<li><a href="/ProductsControllers/ProductsPageCategory?category=Carte électronique">Carte électronique</a></li>
  	 				<li><a href="/ProductsControllers/ProductsPageCategory?category=Appareil de mesure">Appareils de mesure</a></li>
  	 				<li><a href="/ProductsControllers/ProductsPageCategory?category=Composants électronique">pieces électronique</a></li>
  	 				<li><a href="/ProductsControllers/ProductsPageCategory?category=Kit électronique">kits électroniciens</a></li>
  	 			</ul>
  	 		</div>
  	 	</div>
  	 </div>

  	</footer>
   
  <script src="../ressources/js/add_to_panner.js"></script>
  <script src="../ressources/js/navbar.js"></script>

</body>
</html>